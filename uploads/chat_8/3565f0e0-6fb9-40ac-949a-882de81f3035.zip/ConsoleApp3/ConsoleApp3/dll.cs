﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;


//namespace ClassLibrary2
//{
//    public class TcpMulticastServer
//    {
//        private const int TcpPort = 8800;
//        private const int UdpPort = 8801;
//        private const string MulticastIp = "224.5.5.5";
//        private readonly List<TcpClient> _clients = new List<TcpClient>();
//        public Dictionary<string, string> users = new Dictionary<string, string>();

//        public void Start()
//        {
//            TcpListener tcpListener = new TcpListener(IPAddress.Any, TcpPort);
//            tcpListener.Start();
//            Console.WriteLine($"TCP сервер запущен на порте {TcpPort}");

//            new Thread(() =>
//            {
//                while (true)
//                {
//                    TcpClient client = tcpListener.AcceptTcpClient();
//                    lock (_clients)
//                    {
//                        _clients.Add(client);
//                    }
//                    Console.WriteLine("Клиент подключен");
//                    string clIP = ((IPEndPoint)client.Client.LocalEndPoint).Address.ToString();

//                    new Thread(() =>
//                    {
//                        if (users.ContainsKey(clIP))
//                        {
//                            using (NetworkStream stream = client.GetStream())
//                            {
//                                byte[] buffer = new byte[1024];
//                                int bytesRead;
//                                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0)
//                                {
//                                    string message = Encoding.Unicode.GetString(buffer, 0, bytesRead);
//                                    string username = users[clIP];
//                                    string message_post = $"Пользователь {username}: {message}";
//                                    Console.WriteLine(message + " " + message_post);
//                                    BroadcastMessage(message_post);
//                                }
//                            }
//                        }
//                        else
//                        {
//                            using (NetworkStream stream = client.GetStream())
//                            {
//                                Console.WriteLine("Новый клиент подключен");
//                                byte[] buffer = new byte[1024];
//                                int bytesRead;
//                                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0)
//                                {
//                                    string message = Encoding.Unicode.GetString(buffer, 0, bytesRead);
//                                    users.Add(clIP, message);
//                                    string message_post = $"Пользователь {message} вошёл в чат";
//                                    Console.WriteLine(message + " " + message_post);
//                                    BroadcastMessage(message_post);
//                                }
//                            }
//                        }

//                        lock (_clients)
//                        {
//                            _clients.Remove(client);
//                        }
//                        Console.WriteLine("Клиент отключен.");
//                    }).Start();
//                }
//            }).Start();
//        }

//        private void BroadcastMessage(string message_post)
//        {
//            UdpClient udpClient = new UdpClient();
//            udpClient.JoinMulticastGroup(IPAddress.Parse(MulticastIp));

//            byte[] data = Encoding.Unicode.GetBytes(message_post);
//            udpClient.Send(data, data.Length, MulticastIp, UdpPort);
//            udpClient.Close();

//            Console.WriteLine($"Широковещательное сообщение отправлено: {message_post}");
//        }
//    }
//}
