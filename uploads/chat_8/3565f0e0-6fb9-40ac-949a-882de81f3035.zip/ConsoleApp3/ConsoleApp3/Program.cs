﻿
using ClassLibrary2;

class Program
    {
        static void Main(string[] args)
        {
            TcpMulticastServer server = new TcpMulticastServer();
            server.Start();

            Console.WriteLine("Нажмите Enter для завершения работы");
            Console.ReadLine();
        }
    }
